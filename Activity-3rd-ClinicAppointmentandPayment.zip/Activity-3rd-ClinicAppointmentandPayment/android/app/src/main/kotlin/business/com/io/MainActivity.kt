package business.com.io

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
